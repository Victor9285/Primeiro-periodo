package Algoritmo_conteudo12;
import java.util.Scanner;
public class A27 {
    public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);   
        String[] cpf = new String[1000];
        String[] endereco = new String[cpf.length];
        int i = 0;
        while(true){
            System.out.println("Fale o CPF da pessoa " + (i + 1) + ":");
            cpf[i] = scanner.nextLine();
                if(cpf[i].equalsIgnoreCase("0"))
                    break;
            System.out.println("Fale o endereco da pessoa " + (i + 1) + ":");
            endereco[i] = scanner.nextLine();
            i++;
        }
        boolean encontrado = false;
        for(int j = 0; j < i; j++){
            System.out.println("Fale um cpf informado na lista de cpfs");

        }
     scanner.close();
    }
}
