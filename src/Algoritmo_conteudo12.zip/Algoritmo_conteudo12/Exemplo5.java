package Algoritmo_conteudo12;
import java.util.Scanner;
public class Exemplo5 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        int[] numeros = new int[1000];
        for (int i = 0; i < numeros.length; i++){
            System.out.println("Numero "+ (i + 1));
            numeros[i] = scanner.nextInt();
        }


    }

}
